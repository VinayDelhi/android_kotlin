package com.example.lernkotlin.data.model

data class Student(val userName : String, val averageMark: Int)