package com.example.lernkotlin.data.model

data class ApiStudent(val firstName: String, val lastName: String, val averageMark: Int)